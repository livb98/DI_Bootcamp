HOSTNAME = 'localhost'
USERNAME = 'postgres'
PASSWORD = 'Livnath1998@'
DATABASE = 'hackaton1'
