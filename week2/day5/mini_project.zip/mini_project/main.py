
board = ['-','-','-','-','-','-','-','-','-']

def display_board():
    global board

    print( board[0] + '|',  board[1] + '|',  board[2]+ '|')

    print( board[3] + '|',  board[4] + '|',  board[5]+ '|')

    print( board[6] + '|',  board[7] + '|',  board[8]+ '|')  


def player_input(insertItem):
    global board
    count=9
    while count>=0:
        player = int(input('Enter the index (1-9) to place your item: '))
        if 0 <= player < 9:   
            board[player-1] = insertItem
            print(board)
            count-=1
            print(count)
        else:
            print("Invalid index! Please enter a number between 1 and 9.")
            player = int(input('Enter the index (1-9) to place your item: '))

def winner(p1,p2,p3):
    global board
    win=p1==p2==p3
    if board[0] == board[1] == board[2]:
        win=True
        print('win')
    elif board[3] == board[4] == board[5] :
        win=True
        return True
    elif board[6] == board[7] == board[8]:
        win=True
        return True
    elif board[0] == board[3] == board[6] :
        win=True
        return True
    elif board[1] == board[4] == board[7]:
        win=True
        return True
    elif board[3] == board[5] == board[8]:
        win=True
        return True
    elif board[0] == board[4] == board[8]:
        win=True
        return True
    elif board[2] == board[4] == board[6]:
            win=True
            return True
    else:
            win=False
          
# def play():

